
# Painel de Incidentes - WMS

Este repositório contém uma página HTML com embed do painel desenvolvido no Figma.

## Como publicar

1. Faça fork ou clone deste repositório.
2. Acesse https://vercel.com
3. Clique em "New Project" e selecione este repositório.
4. Publique usando configuração "Other" (sem framework).
